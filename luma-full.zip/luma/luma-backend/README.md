# Luma Backend

> **Ab sab kuch ek hi `server.js` me hai** (pehle `src/` ke andar 20+ files thi). Files: `server.js`, `package.json`, `.env.example`, `railway.json`.

Luma (Instagram-jaisa social app) ka real backend. **Node.js + Express + MongoDB (Mongoose)**.
Saara data MongoDB me save hota hai — users, posts, comments, likes, stories, messages, notifications, aur **photos/videos bhi (GridFS)**. Koi alag file storage (Cloudinary/S3) nahi chahiye.

## Features
- Signup / login (cookie session, bcrypt), OTP verify (email), forgot password, logout-all-devices
- Profile edit, avatar, follow / unfollow, followers / following, suggestions
- Posts (photo, carousel, video), like, save, comments, delete, hashtags
- Feed, Explore grid, Search (people + #hashtag), Reels (video posts)
- Stories (24 ghante baad auto-delete), close friends, viewers list
- Direct messages (1-to-1, unread count, reactions), notifications, activity, reports
- Account delete + data export, settings save

---

## 1) Local me chalana

```bash
cd luma-backend
npm install
cp .env.example .env        # .env me MONGODB_URI aur JWT_SECRET bharo
npm run dev                 # http://localhost:4000/health
```

Frontend (`app/`) me `.env` banao: `VITE_API_BASE_URL=http://localhost:4000` phir `npm run dev` (port 3000).

## 2) MongoDB Atlas (free)
1. https://www.mongodb.com/atlas -> Free cluster (M0) banao.
2. **Database Access** -> user + password banao.
3. **Network Access** -> `0.0.0.0/0` allow karo (Railway ka IP fixed nahi hota).
4. **Connect -> Drivers** se connection string copy karo. Beech me DB naam daalo:
   `mongodb+srv://USER:PASS@cluster0.xxxx.mongodb.net/luma?retryWrites=true&w=majority`
   (password me special character ho to URL-encode karo.)

## 3) GitHub pe daalna
```bash
cd luma-backend
git init && git add . && git commit -m "Luma backend"
git branch -M main
git remote add origin https://github.com/<tumhara-username>/luma-backend.git
git push -u origin main
```
`.env` automatically ignore hoti hai (`.gitignore`) — secrets GitHub pe nahi jaate.
Agar frontend aur backend ek hi repo me rakhne ho to folders `frontend/` aur `backend/` banao aur Railway me **Root Directory = backend** set karo.

## 4) Railway pe deploy
1. railway.app -> **New Project -> Deploy from GitHub repo** -> repo select karo.
2. **Variables** tab me ye daalo:

| Variable | Value |
|---|---|
| `MONGODB_URI` | Atlas wali string |
| `JWT_SECRET` | 48+ random chars (`node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`) |
| `NODE_ENV` | `production` |
| `FRONTEND_ORIGINS` | frontend ka URL, e.g. `https://luma.vercel.app` (comma se multiple) |
| `PUBLIC_URL` | Railway ka public URL, e.g. `https://luma-api.up.railway.app` |
| `REQUIRE_VERIFICATION` | pehle testing me `false`, baad me `true` |

3. **Settings -> Networking -> Generate Domain** se public URL lo (wahi `PUBLIC_URL` me daalo).
4. Deploy ke baad `https://<domain>/health` kholo -> `{"ok":true,"db":"up"}` aana chahiye.

`railway.json` me start command aur healthcheck pehle se set hai. `PORT` Railway khud deta hai.

## 5) Frontend connect karna
Frontend ke hosting (Vercel/Netlify/Railway) me variable: `VITE_API_BASE_URL=https://<railway-domain>` (end me `/` nahi) — phir frontend redeploy.
Bhejne ke saath `frontend-patch/src/lib/api.ts` se apna `src/lib/api.ts` replace karo (error messages sahi dikhte hain).

**Cookie ka dhyan:** login cookie me hota hai (`httpOnly`, `Secure`, `SameSite=None`). Frontend aur backend alag domains pe ho to Safari/Brave third-party cookies block kar sakte hain. Sabse safe: dono ko ek hi domain ke andar rakho (`app.tumhara.com` + `api.tumhara.com`) aur Railway me `COOKIE_DOMAIN=.tumhara.com` set karo.

## 6) OTP / email
- `REQUIRE_VERIFICATION=false` -> signup ke turant baad account active, OTP step skip (testing ke liye best).
- `true` + `RESEND_API_KEY` (https://resend.com, free) + `MAIL_FROM` -> email pe real code jaata hai. (Resend me apna domain verify karna padta hai, warna sirf apne email pe bhej sakte ho.) Ye HTTP API hai, Railway pe SMTP block hone ki dikkat nahi.
- `LOG_OTP=true` -> code Railway logs me print hota hai (sirf testing).
- **Phone number** OTP ke liye SMS provider (Twilio etc.) chahiye — abhi integrate nahi hai; phone signup tab `REQUIRE_VERIFICATION=false` me hi chalega.

## API (sab `/api` ke andar, JSON, cookie auth)

| Area | Endpoints |
|---|---|
| Auth | `GET auth/session` · `POST auth/signup` · `POST auth/login` · `POST auth/logout` · `POST auth/logout-all` · `GET auth/username-availability?username=` · `POST auth/otp/request` · `POST auth/otp/verify` (`purpose: "reset"` -> `resetToken`) · `POST auth/password/reset` `{resetToken,password}` |
| Media | `POST media` (multipart, field `file`) -> `{id,url}` · `GET media/:id` |
| Users | `GET users/me` · `PATCH users/me` `{name,bio,username,avatarMediaId}` · `PATCH users/me/settings` · `POST users/me/password` · `DELETE users/me` `{password}` · `GET users/me/export` · `GET/PUT users/me/close-friends` · `GET users/suggestions` · `GET users/:username` · `GET users/:username/posts` · `GET users/:username/followers\|following` · `POST/DELETE users/:username/follow` |
| Posts | `GET posts/feed` · `GET posts/saved` · `POST posts` `{mediaIds,caption,location}` · `GET/PATCH/DELETE posts/:id` · `POST/DELETE posts/:id/like` · `POST/DELETE posts/:id/save` · `GET/POST posts/:id/comments` · `DELETE posts/:id/comments/:commentId` |
| Stories | `GET stories` · `POST stories` `{mediaId,closeFriends}` · `POST stories/:id/view` · `GET stories/:id/viewers` · `DELETE stories/:id` |
| Reels | `GET reels` |
| Messages | `GET conversations` · `POST conversations` `{username}` · `GET conversations/:id/messages?after=` · `POST conversations/:id/messages` `{text}` · `PUT .../messages/:mid/reaction` `{emoji}` · `DELETE .../messages/:mid` |
| Notifications | `GET notifications` · `GET notifications/unread-count` · `POST notifications/read` |
| Other | `GET explore?page=` · `GET search?q=` (`#tag` bhi) · `GET activity` · `POST reports` |

Lists cursor-paginated hain: `?cursor=<nextCursor>&limit=`. Errors: `{ "error": "message", "code": "..." }`.
**Post banana:** pehle har file `POST /api/media` se upload karo -> milte hue `id` ko `POST /api/posts` me `mediaIds` me bhejo.

## Abhi ye nahi hai (agle steps)
- Realtime chat (Socket.IO) — abhi polling (`?after=`) se chalta hai
- SMS OTP, 2FA, private accounts / follow requests, admin panel (blue tick `verifiedBadge` Atlas se manually true karo)
- Bade videos ke liye object storage (abhi max `MAX_UPLOAD_MB`, default 50MB, GridFS me)

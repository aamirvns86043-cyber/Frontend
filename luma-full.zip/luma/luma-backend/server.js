"use strict";
/**
 * Luma API — everything in ONE file (config, database, models, helpers, all routes, server start).
 * Run: node server.js     (needs the packages listed in package.json)
 */
require("dotenv").config();

const crypto = require("node:crypto");
const { pipeline } = require("node:stream/promises");
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const rlMod = require("express-rate-limit");
const rateLimit = rlMod.rateLimit || rlMod;
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const multer = require("multer");

const { Router } = express;


// ======================================================================
// CONFIG
// ======================================================================

const config = (() => {
  const env = process.env;
  const isProd = env.NODE_ENV === 'production';

  for (const key of ['MONGODB_URI', 'JWT_SECRET']) {
    if (!env[key]) {
      console.error(`Missing required environment variable: ${key}`);
      process.exit(1);
    }
  }
  if (isProd && env.JWT_SECRET.length < 32) {
    console.error('JWT_SECRET must be at least 32 characters in production.');
    process.exit(1);
  }

  const clean = (url) => url.trim().replace(/\/+$/, '');
  const sameSite = (env.COOKIE_SAMESITE || (isProd ? 'none' : 'lax')).toLowerCase();

  const cfg = {
    isProd,
    port: Number(env.PORT) || 4000,
    mongoUri: env.MONGODB_URI,
    jwtSecret: env.JWT_SECRET,
    allowedOrigins: (env.FRONTEND_ORIGINS || 'http://localhost:3000').split(',').map(clean).filter(Boolean),
    publicUrl: env.PUBLIC_URL ? clean(env.PUBLIC_URL) : '',
    cookie: {
      name: 'luma_session',
      sameSite,
      secure: isProd || sameSite === 'none',
      domain: env.COOKIE_DOMAIN || undefined,
      maxAgeMs: 30 * 24 * 60 * 60 * 1000,
    },
    requireVerification: env.REQUIRE_VERIFICATION !== 'false',
    logOtp: env.LOG_OTP ? env.LOG_OTP === 'true' : !isProd,
    resendApiKey: env.RESEND_API_KEY || '',
    mailFrom: env.MAIL_FROM || 'Luma <onboarding@resend.dev>',
    maxUploadBytes: (Number(env.MAX_UPLOAD_MB) || 50) * 1024 * 1024,
  };
  return cfg;
})();


// ======================================================================
// DATABASE (MongoDB + GridFS for photos/videos)
// ======================================================================

let bucket = null;

async function connectDb() {
  mongoose.set('strictQuery', true);
  await mongoose.connect(config.mongoUri, { serverSelectionTimeoutMS: 15000, maxPoolSize: 10 });
  bucket = new mongoose.mongo.GridFSBucket(mongoose.connection.db, { bucketName: 'media' });
  console.log('MongoDB connected');
}

function getBucket() {
  if (!bucket) throw new Error('Database is not ready yet.');
  return bucket;
}

const toObjectId = (id) => new mongoose.Types.ObjectId(String(id));

/** Delete GridFS files by id. Missing files are ignored. */
async function deleteMedia(ids) {
  const list = (ids || []).filter(Boolean);
  await Promise.all(
    list.map(async (id) => {
      try { await getBucket().delete(toObjectId(id)); } catch { /* already gone */ }
    }),
  );
}


// ======================================================================
// HELPERS: errors, validation
// ======================================================================

class HttpError extends Error {
  constructor(status, message, code) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function notFound(req, res, next) {
  next(new HttpError(404, 'Route not found.', 'NOT_FOUND'));
}

// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  let status = err.status || 500;
  let message = err.message;
  let code = err.code && typeof err.code === 'string' ? err.code : undefined;

  if (err.name === 'ValidationError') { status = 400; message = Object.values(err.errors).map((e) => e.message).join(' '); code = 'VALIDATION'; }
  else if (err.name === 'CastError') { status = 400; message = 'Invalid value.'; code = 'VALIDATION'; }
  else if (err.code === 11000) { status = 409; message = 'That value is already in use.'; code = 'DUPLICATE'; }
  else if (err.name === 'MulterError') { status = err.code === 'LIMIT_FILE_SIZE' ? 413 : 400; message = err.code === 'LIMIT_FILE_SIZE' ? 'File is too large.' : 'Upload failed.'; code = 'UPLOAD'; }
  else if (err.type === 'entity.too.large') { status = 413; message = 'Request body too large.'; }
  else if (err.type === 'entity.parse.failed') { status = 400; message = 'Invalid JSON.'; }

  if (status >= 500) {
    console.error(err);
    message = 'Something went wrong on our side.';
    code = 'SERVER_ERROR';
  }
  res.status(status).json({ error: message, ...(code ? { code } : {}) });
}

const ah = asyncHandler;

const isId = (v) => typeof v === 'string' && /^[a-f\d]{24}$/i.test(v);

function needId(v, name = 'id') {
  if (!isId(v)) throw new HttpError(400, `Invalid ${name}.`, 'VALIDATION');
  return v;
}

function text(v, { name = 'Field', min = 0, max = 500 } = {}) {
  if (v === undefined || v === null || v === '') {
    if (min > 0) throw new HttpError(400, `${name} is required.`, 'VALIDATION');
    return '';
  }
  if (typeof v !== 'string') throw new HttpError(400, `${name} must be text.`, 'VALIDATION');
  const t = v.trim();
  if (t.length < min) throw new HttpError(400, `${name} is required.`, 'VALIDATION');
  if (t.length > max) throw new HttpError(400, `${name} must be at most ${max} characters.`, 'VALIDATION');
  return t;
}

const USERNAME_RE = /^[a-z0-9._]{3,30}$/;
function normalizeUsername(v) {
  const u = String(v || '').trim().toLowerCase().replace(/^@/, '');
  if (!USERNAME_RE.test(u)) throw new HttpError(400, 'Username must be 3–30 characters: letters, numbers, dot or underscore.', 'VALIDATION');
  return u;
}

/** Returns { type: 'email' | 'phone', value } or null. */
function parseContact(raw) {
  const v = String(raw || '').trim();
  if (!v) return null;
  if (v.includes('@')) {
    const email = v.toLowerCase();
    return email.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email) ? { type: 'email', value: email } : null;
  }
  const phone = v.replace(/[\s\-().]/g, '');
  return /^\+?\d{7,15}$/.test(phone) ? { type: 'phone', value: phone } : null;
}

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

function pageLimit(raw, def = 10, max = 30) {
  const n = parseInt(raw, 10);
  return Number.isFinite(n) ? Math.min(Math.max(n, 1), max) : def;
}

function password(raw, name = 'Password') {
  const p = typeof raw === 'string' ? raw : '';
  if (p.length < 10) throw new HttpError(400, `${name} must be at least 10 characters.`, 'VALIDATION');
  if (p.length > 128) throw new HttpError(400, `${name} is too long.`, 'VALIDATION');
  return p;
}

const checkPassword = password;


// ======================================================================
// MODELS
// ======================================================================

const { Schema } = mongoose;
const ObjectId = Schema.Types.ObjectId;

/* ---------- User ---------- */
const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 60 },
  username: { type: String, required: true, unique: true, lowercase: true, trim: true, minlength: 3, maxlength: 30, match: /^[a-z0-9._]+$/ },
  email: { type: String, lowercase: true, trim: true, unique: true, sparse: true },
  phone: { type: String, trim: true, unique: true, sparse: true },
  passwordHash: { type: String, required: true, select: false },
  bio: { type: String, default: '', maxlength: 160 },
  avatarMediaId: { type: ObjectId, default: null },
  verifiedBadge: { type: Boolean, default: false }, // blue tick: set manually in Atlas
  contactVerified: { type: Boolean, default: false },
  settings: { type: Schema.Types.Mixed, default: {} },
  closeFriendIds: [{ type: ObjectId }],
  lastSeenAt: Date,
  tokenVersion: { type: Number, default: 0 },
}, { timestamps: true, minimize: false });
userSchema.index({ name: 1 });

/* ---------- Follow / Like / Save ---------- */
const followSchema = new Schema({
  follower: { type: ObjectId, required: true },
  following: { type: ObjectId, required: true },
}, { timestamps: { createdAt: true, updatedAt: false } });
followSchema.index({ follower: 1, following: 1 }, { unique: true });
followSchema.index({ following: 1, _id: -1 });

const likeSchema = new Schema({
  user: { type: ObjectId, required: true },
  post: { type: ObjectId, required: true },
}, { timestamps: { createdAt: true, updatedAt: false } });
likeSchema.index({ user: 1, post: 1 }, { unique: true });
likeSchema.index({ post: 1 });

const saveSchema = new Schema({
  user: { type: ObjectId, required: true },
  post: { type: ObjectId, required: true },
}, { timestamps: { createdAt: true, updatedAt: false } });
saveSchema.index({ user: 1, post: 1 }, { unique: true });
saveSchema.index({ user: 1, _id: -1 });

/* ---------- Post / Comment ---------- */
const postSchema = new Schema({
  author: { type: ObjectId, required: true },
  type: { type: String, enum: ['image', 'video', 'carousel'], required: true },
  media: [{
    _id: false,
    mediaId: { type: ObjectId, required: true },
    kind: { type: String, enum: ['image', 'video'], required: true },
  }],
  posterId: { type: ObjectId, default: null },
  audio: { type: String, default: '', maxlength: 100 },
  caption: { type: String, default: '', maxlength: 2200 },
  location: { type: String, default: '', maxlength: 100 },
  tags: [{ type: String }],
  likesCount: { type: Number, default: 0, min: 0 },
  commentsCount: { type: Number, default: 0, min: 0 },
}, { timestamps: true });
postSchema.index({ author: 1, _id: -1 });
postSchema.index({ tags: 1, _id: -1 });
postSchema.index({ type: 1, _id: -1 });
postSchema.index({ likesCount: -1, _id: -1 });

const commentSchema = new Schema({
  post: { type: ObjectId, required: true },
  author: { type: ObjectId, required: true },
  text: { type: String, required: true, maxlength: 500 },
}, { timestamps: { createdAt: true, updatedAt: false } });
commentSchema.index({ post: 1, _id: -1 });
commentSchema.index({ author: 1, _id: -1 });

/* ---------- Story ---------- */
const storySchema = new Schema({
  author: { type: ObjectId, required: true },
  mediaId: { type: ObjectId, required: true },
  kind: { type: String, enum: ['image', 'video'], required: true },
  closeFriends: { type: Boolean, default: false },
  viewers: [{ type: ObjectId }],
  expiresAt: { type: Date, required: true },
}, { timestamps: { createdAt: true, updatedAt: false } });
storySchema.index({ author: 1, expiresAt: -1 });
storySchema.index({ expiresAt: 1 });

/* ---------- Messaging ---------- */
const conversationSchema = new Schema({
  participants: [{ type: ObjectId, required: true }],
  pairKey: { type: String, required: true, unique: true },
  lastText: { type: String, default: '' },
  lastSender: { type: ObjectId, default: null },
  lastMessageAt: { type: Date, default: Date.now },
  unread: { type: Schema.Types.Mixed, default: {} }, // { "<userId>": count }
}, { timestamps: true, minimize: false });
conversationSchema.index({ participants: 1, lastMessageAt: -1 });

const messageSchema = new Schema({
  conversation: { type: ObjectId, required: true },
  sender: { type: ObjectId, required: true },
  text: { type: String, default: '', maxlength: 2000 },
  reaction: { type: String, default: '', maxlength: 8 },
  deleted: { type: Boolean, default: false },
}, { timestamps: { createdAt: true, updatedAt: false } });
messageSchema.index({ conversation: 1, _id: -1 });

/* ---------- Notifications ---------- */
const notificationSchema = new Schema({
  recipient: { type: ObjectId, required: true },
  actor: { type: ObjectId, required: true },
  type: { type: String, enum: ['like', 'comment', 'follow'], required: true },
  post: { type: ObjectId, default: null },
  text: { type: String, default: '', maxlength: 200 },
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now },
});
notificationSchema.index({ recipient: 1, createdAt: -1 });
notificationSchema.index({ post: 1 });

/* ---------- OTP / Reports ---------- */
const otpSchema = new Schema({
  contact: { type: String, required: true },
  purpose: { type: String, enum: ['signup', 'reset'], required: true },
  codeHash: { type: String, required: true },
  attempts: { type: Number, default: 0 },
  lastSentAt: { type: Date, default: Date.now },
  expiresAt: { type: Date, required: true },
});
otpSchema.index({ contact: 1, purpose: 1 }, { unique: true });
otpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

const reportSchema = new Schema({
  reporter: { type: ObjectId, required: true },
  targetType: { type: String, enum: ['post', 'user', 'comment', 'story', 'message'], required: true },
  target: { type: String, required: true, maxlength: 60 },
  reason: { type: String, required: true, maxlength: 100 },
  details: { type: String, default: '', maxlength: 1000 },
  status: { type: String, enum: ['open', 'reviewed', 'dismissed'], default: 'open' },
}, { timestamps: true });

const model = (name, schema) => mongoose.models[name] || mongoose.model(name, schema);
const User = model('User', userSchema);
const Follow = model('Follow', followSchema);
const Like = model('Like', likeSchema);
const Save = model('Save', saveSchema);
const Post = model('Post', postSchema);
const Comment = model('Comment', commentSchema);
const Story = model('Story', storySchema);
const Conversation = model('Conversation', conversationSchema);
const Message = model('Message', messageSchema);
const Notification = model('Notification', notificationSchema);
const Otp = model('Otp', otpSchema);
const Report = model('Report', reportSchema);


// ======================================================================
// HELPERS: serializers, hydrate, media, notifications, OTP, cascade deletes
// ======================================================================

function ctxFrom(req) {
  return { base: config.publicUrl || `${req.protocol}://${req.get('host')}` };
}

const mediaUrl = (ctx, id) => (id ? `${ctx.base}/api/media/${id}` : '');

function shortTime(date) {
  const d = new Date(date);
  const s = Math.max(0, (Date.now() - d.getTime()) / 1000);
  if (s < 60) return 'now';
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  if (s < 86400) return `${Math.floor(s / 3600)}h`;
  if (s < 604800) return `${Math.floor(s / 86400)}d`;
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

const ONLINE_WINDOW_MS = 5 * 60 * 1000;

function userDTO(ctx, u) {
  if (!u) return null;
  return {
    id: String(u._id),
    name: u.name,
    username: u.username,
    avatar: u.avatarMediaId ? mediaUrl(ctx, u.avatarMediaId) : `${ctx.base}/api/users/${u.username}/avatar.svg`,
    bio: u.bio || '',
    verified: !!u.verifiedBadge,
    online: !!u.lastSeenAt && Date.now() - new Date(u.lastSeenAt).getTime() < ONLINE_WINDOW_MS,
  };
}

function meDTO(ctx, u) {
  return {
    ...userDTO(ctx, u),
    email: u.email || null,
    phone: u.phone || null,
    contactVerified: !!u.contactVerified,
    settings: u.settings || {},
    createdAt: u.createdAt,
  };
}

function commentDTO(ctx, c, user) {
  return { id: String(c._id), user: userDTO(ctx, user), text: c.text, time: shortTime(c.createdAt), createdAt: c.createdAt };
}

/** Small square thumbnail info for a post (used by notifications / activity). */
function thumbDTO(ctx, p) {
  if (!p) return null;
  const firstImage = (p.media || []).find((m) => m.kind === 'image');
  return {
    id: String(p._id),
    type: p.type,
    image: firstImage ? mediaUrl(ctx, firstImage.mediaId) : mediaUrl(ctx, p.posterId),
  };
}

function postDTO(ctx, p, users, { liked = false, saved = false, preview = [] } = {}) {
  const media = p.media || [];
  const images = media.filter((m) => m.kind === 'image').map((m) => mediaUrl(ctx, m.mediaId));
  const video = media.find((m) => m.kind === 'video');
  const poster = p.posterId ? mediaUrl(ctx, p.posterId) : '';
  return {
    id: String(p._id),
    user: userDTO(ctx, users.get(String(p.author))),
    type: p.type,
    image: images[0] || poster,
    ...(video ? { video: mediaUrl(ctx, video.mediaId), poster } : {}),
    ...(p.type === 'carousel' ? { images } : {}),
    audio: p.audio || undefined,
    location: p.location || '',
    caption: p.caption || '',
    likes: p.likesCount,
    commentsCount: p.commentsCount,
    comments: preview.map((c) => commentDTO(ctx, c, users.get(String(c.author)))),
    time: shortTime(p.createdAt),
    createdAt: p.createdAt,
    liked,
    saved,
  };
}

/** Turns raw Post docs into API objects (author, liked/saved flags, latest 2 comments). */
async function hydratePosts(ctx, posts, me) {
  if (!posts.length) return [];
  const ids = posts.map((p) => p._id);
  const [likes, saves, previews] = await Promise.all([
    Like.find({ user: me._id, post: { $in: ids } }).select('post').lean(),
    Save.find({ user: me._id, post: { $in: ids } }).select('post').lean(),
    Promise.all(ids.map((id) => Comment.find({ post: id }).sort({ _id: -1 }).limit(2).lean())),
  ]);
  const userIds = new Set(posts.map((p) => String(p.author)));
  previews.flat().forEach((c) => userIds.add(String(c.author)));
  const users = new Map((await User.find({ _id: { $in: [...userIds] } })).map((u) => [String(u._id), u]));
  const likedSet = new Set(likes.map((l) => String(l.post)));
  const savedSet = new Set(saves.map((s) => String(s.post)));

  return posts
    .map((p, i) => (users.has(String(p.author))
      ? postDTO(ctx, p, users, {
        liked: likedSet.has(String(p._id)),
        saved: savedSet.has(String(p._id)),
        preview: previews[i].slice().reverse(), // oldest -> newest
      })
      : null))
    .filter(Boolean);
}

/** Returns an array aligned with `ids`: the GridFS file doc if it exists AND belongs to ownerId, else null. */
async function findOwnedMedia(ids, ownerId) {
  if (!ids.length) return [];
  const files = await getBucket()
    .find({ _id: { $in: ids.map(toObjectId) }, 'metadata.owner': ownerId })
    .toArray();
  const byId = new Map(files.map((f) => [String(f._id), f]));
  return ids.map((id) => byId.get(String(id)) || null);
}

async function notify({ recipient, actor, type, post = null, text = '' }) {
  if (String(recipient) === String(actor)) return;
  try {
    if (type === 'comment') {
      await Notification.create({ recipient, actor, type, post, text: text.slice(0, 200) });
      return;
    }
    // like / follow: one notification per (actor, target); re-liking just bumps it
    await Notification.updateOne(
      { recipient, actor, type, post },
      { $set: { read: false, createdAt: new Date() } },
      { upsert: true },
    );
  } catch (err) {
    console.error('notify failed', err.message); // never break the main action
  }
}

async function unnotify({ recipient, actor, type, post = null }) {
  try { await Notification.deleteMany({ recipient, actor, type, post }); } catch { /* ignore */ }
}

const TTL_MS = 10 * 60 * 1000;
const COOLDOWN_MS = 30 * 1000;
const MAX_ATTEMPTS = 5;

const hash = (contact, purpose, code) =>
  crypto.createHmac('sha256', config.jwtSecret).update(`${contact}:${purpose}:${code}`).digest('hex');

async function deliver(contact, code, purpose) {
  const isEmail = contact.includes('@');
  if (isEmail && config.resendApiKey) {
    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${config.resendApiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: config.mailFrom,
        to: [contact],
        subject: purpose === 'reset' ? 'Reset your Luma password' : 'Your Luma verification code',
        text: `Your Luma code is ${code}. It expires in 10 minutes. If you didn't ask for this, ignore this email.`,
      }),
    });
    if (!res.ok) console.error('Resend failed:', res.status, await res.text().catch(() => ''));
    return;
  }
  // No provider for this contact type (e.g. phone/SMS): only log when explicitly allowed.
  if (config.logOtp) console.log(`[OTP:${purpose}] ${contact} -> ${code}`);
}

async function issueOtp(contact, purpose) {
  const existing = await Otp.findOne({ contact, purpose }).select('lastSentAt');
  if (existing && Date.now() - existing.lastSentAt.getTime() < COOLDOWN_MS) {
    throw new HttpError(429, 'Please wait a moment before requesting another code.', 'OTP_COOLDOWN');
  }
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  await Otp.findOneAndUpdate(
    { contact, purpose },
    { codeHash: hash(contact, purpose, code), attempts: 0, lastSentAt: new Date(), expiresAt: new Date(Date.now() + TTL_MS) },
    { upsert: true },
  );
  await deliver(contact, code, purpose);
}

/** Throws unless the code is right. A correct code is single-use. */
async function consumeOtp(contact, purpose, code) {
  const bad = new HttpError(400, 'That code is invalid or has expired.', 'OTP_INVALID');
  if (!/^\d{6}$/.test(String(code || ''))) throw bad;
  // atomic attempt counter so parallel guesses can't beat the limit
  const doc = await Otp.findOneAndUpdate({ contact, purpose }, { $inc: { attempts: 1 } }, { new: true });
  if (!doc || doc.expiresAt < new Date()) throw bad;
  if (doc.attempts > MAX_ATTEMPTS) {
    await Otp.deleteOne({ _id: doc._id });
    throw new HttpError(429, 'Too many wrong attempts. Request a new code.', 'OTP_LOCKED');
  }
  const expected = Buffer.from(doc.codeHash, 'hex');
  const actual = Buffer.from(hash(contact, purpose, String(code)), 'hex');
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) throw bad;
  await Otp.deleteOne({ _id: doc._id });
}

async function deletePost(post) {
  const mediaIds = [...(post.media || []).map((m) => m.mediaId), post.posterId].filter(Boolean);
  await Promise.all([
    Like.deleteMany({ post: post._id }),
    Save.deleteMany({ post: post._id }),
    Comment.deleteMany({ post: post._id }),
    Notification.deleteMany({ post: post._id }),
  ]);
  await Post.deleteOne({ _id: post._id });
  await deleteMedia(mediaIds);
}

async function recountPosts(postIds) {
  for (const id of postIds) {
    const [likes, comments] = await Promise.all([Like.countDocuments({ post: id }), Comment.countDocuments({ post: id })]);
    await Post.updateOne({ _id: id }, { likesCount: likes, commentsCount: comments });
  }
}

/** Removes a user and everything that belongs to them. */
async function deleteUser(userId) {
  const posts = await Post.find({ author: userId });
  for (const p of posts) await deletePost(p);

  const stories = await Story.find({ author: userId }).select('mediaId');
  await deleteMedia(stories.map((s) => s.mediaId));
  await Story.deleteMany({ author: userId });

  const likedPosts = await Like.find({ user: userId }).distinct('post');
  const commentedPosts = await Comment.find({ author: userId }).distinct('post');
  await Like.deleteMany({ user: userId });
  await Comment.deleteMany({ author: userId });
  await recountPosts([...new Set([...likedPosts, ...commentedPosts].map(String))]);

  await Promise.all([
    Save.deleteMany({ user: userId }),
    Follow.deleteMany({ $or: [{ follower: userId }, { following: userId }] }),
    Notification.deleteMany({ $or: [{ recipient: userId }, { actor: userId }] }),
  ]);

  const convIds = await Conversation.find({ participants: userId }).distinct('_id');
  await Message.deleteMany({ conversation: { $in: convIds } });
  await Conversation.deleteMany({ _id: { $in: convIds } });

  const user = await User.findById(userId).select('avatarMediaId');
  if (user?.avatarMediaId) await deleteMedia([user.avatarMediaId]);
  await User.deleteOne({ _id: userId });
}

/** Hourly job: remove stories that expired (and their media files). */
async function cleanupExpiredStories() {
  const expired = await Story.find({ expiresAt: { $lt: new Date() } }).limit(200).select('mediaId');
  if (!expired.length) return;
  await deleteMedia(expired.map((s) => s.mediaId));
  await Story.deleteMany({ _id: { $in: expired.map((s) => s._id) } });
}


// ======================================================================
// AUTH MIDDLEWARE
// ======================================================================

const cookieOptions = () => ({
  httpOnly: true,
  secure: config.cookie.secure,
  sameSite: config.cookie.sameSite,
  path: '/',
  ...(config.cookie.domain ? { domain: config.cookie.domain } : {}),
});

function setSessionCookie(res, user) {
  const token = jwt.sign({ tv: user.tokenVersion }, config.jwtSecret, {
    subject: String(user._id), audience: 'session', expiresIn: '30d', algorithm: 'HS256',
  });
  res.cookie(config.cookie.name, token, { ...cookieOptions(), maxAge: config.cookie.maxAgeMs });
}

function clearSessionCookie(res) {
  res.clearCookie(config.cookie.name, cookieOptions());
}

/** Reads the session cookie and attaches req.user (if valid). Never rejects. */
const loadUser = asyncHandler(async (req, res, next) => {
  const token = req.cookies?.[config.cookie.name];
  if (!token) return next();
  try {
    const payload = jwt.verify(token, config.jwtSecret, { audience: 'session', algorithms: ['HS256'] });
    const user = await User.findById(payload.sub);
    if (user && user.tokenVersion === payload.tv) {
      req.user = user;
      if (!user.lastSeenAt || Date.now() - user.lastSeenAt.getTime() > 2 * 60 * 1000) {
        User.updateOne({ _id: user._id }, { lastSeenAt: new Date() }).catch(() => {});
      }
    }
  } catch { /* invalid or expired token -> treated as logged out */ }
  next();
});

function requireAuth(req, res, next) {
  if (!req.user) return next(new HttpError(401, 'Please log in.', 'UNAUTHENTICATED'));
  next();
}

/** CSRF protection for cookie auth: browsers always send Origin on cross-site writes. */
function originGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const origin = req.get('origin');
  const sameOrigin = origin === `${req.protocol}://${req.get('host')}`; // frontend served by this same server
  if (origin && !sameOrigin && !config.allowedOrigins.includes(origin.replace(/\/+$/, ''))) {
    return next(new HttpError(403, 'Origin not allowed.', 'BAD_ORIGIN'));
  }
  next();
}


// ======================================================================
// ROUTES
// ======================================================================

// ---- routes/auth.js ----
const authRoutes = (() => {
  const r = Router();
  const limiter = (limit) => rateLimit({
    windowMs: 15 * 60 * 1000, limit, standardHeaders: true, legacyHeaders: false,
    message: { error: 'Too many attempts. Please try again later.', code: 'RATE_LIMITED' },
  });
  const authLimiter = limiter(20);
  const otpLimiter = limiter(10);
  const availabilityLimiter = limiter(120);

  const DUMMY_HASH = bcrypt.hashSync('luma-dummy-password', 12); // keeps login timing similar for unknown users

  r.get('/session', (req, res) => {
    res.json({ user: req.user ? meDTO(ctxFrom(req), req.user) : null });
  });

  r.get('/username-availability', availabilityLimiter, ah(async (req, res) => {
    let username;
    try { username = normalizeUsername(req.query.username); } catch (e) { return res.json({ available: false, reason: e.message }); }
    res.json({ available: !(await User.exists({ username })) });
  }));

  r.post('/signup', authLimiter, ah(async (req, res) => {
    const name = text(req.body.name, { name: 'Name', min: 1, max: 60 });
    const username = normalizeUsername(req.body.username);
    const contact = parseContact(req.body.contact);
    if (!contact) throw new HttpError(400, 'Enter a valid email address or phone number.', 'VALIDATION');
    const pass = checkPassword(req.body.password);

    const clash = await User.find({ $or: [{ username }, { [contact.type]: contact.value }] }).select('contactVerified');
    if (clash.some((u) => u.contactVerified)) throw new HttpError(409, 'That username or contact is already in use.', 'TAKEN');
    if (clash.length) await User.deleteMany({ _id: { $in: clash.map((u) => u._id) } }); // abandoned, never-verified signups

    const user = await User.create({
      name, username, [contact.type]: contact.value,
      passwordHash: await bcrypt.hash(pass, 12),
      contactVerified: !config.requireVerification,
    });

    if (!config.requireVerification) {
      setSessionCookie(res, user);
      return res.status(201).json({ ok: true, requiresVerification: false, user: meDTO(ctxFrom(req), user) });
    }
    await issueOtp(contact.value, 'signup');
    res.status(201).json({ ok: true, requiresVerification: true, contact: contact.value });
  }));

  /** Send a code. Always answers ok so nobody can probe which accounts exist. */
  r.post('/otp/request', otpLimiter, ah(async (req, res) => {
    const contact = parseContact(req.body.contact);
    const purpose = req.body.purpose === 'signup' ? 'signup' : 'reset';
    if (contact) {
      const user = await User.findOne({ [contact.type]: contact.value }).select('contactVerified');
      const eligible = user && (purpose === 'reset' ? user.contactVerified : !user.contactVerified);
      if (eligible) {
        try { await issueOtp(contact.value, purpose); } catch (e) { if (!(e instanceof HttpError && e.status === 429)) throw e; }
      }
    }
    res.json({ ok: true });
  }));

  r.post('/otp/verify', otpLimiter, ah(async (req, res) => {
    const contact = parseContact(req.body.contact);
    const purpose = req.body.purpose === 'reset' ? 'reset' : 'signup';
    if (!contact) throw new HttpError(400, 'That code is invalid or has expired.', 'OTP_INVALID');
    await consumeOtp(contact.value, purpose, req.body.code);

    const user = await User.findOne({ [contact.type]: contact.value });
    if (!user) throw new HttpError(400, 'That code is invalid or has expired.', 'OTP_INVALID');

    if (purpose === 'signup') {
      if (!user.contactVerified) { user.contactVerified = true; await user.save(); }
      setSessionCookie(res, user);
      return res.json({ ok: true, user: meDTO(ctxFrom(req), user) });
    }
    if (!user.contactVerified) throw new HttpError(400, 'That code is invalid or has expired.', 'OTP_INVALID');
    const resetToken = jwt.sign({ tv: user.tokenVersion }, config.jwtSecret, {
      subject: String(user._id), audience: 'reset', expiresIn: '10m', algorithm: 'HS256',
    });
    res.json({ ok: true, resetToken });
  }));

  r.post('/password/reset', authLimiter, ah(async (req, res) => {
    const pass = checkPassword(req.body.password, 'New password');
    let payload;
    try {
      payload = jwt.verify(String(req.body.resetToken || ''), config.jwtSecret, { audience: 'reset', algorithms: ['HS256'] });
    } catch { throw new HttpError(400, 'Reset session expired. Please start again.', 'RESET_EXPIRED'); }
    const user = await User.findById(payload.sub);
    if (!user || user.tokenVersion !== payload.tv) throw new HttpError(400, 'Reset session expired. Please start again.', 'RESET_EXPIRED');
    user.passwordHash = await bcrypt.hash(pass, 12);
    user.tokenVersion += 1; // signs out every device and makes the reset token single-use
    await user.save();
    clearSessionCookie(res);
    res.json({ ok: true });
  }));

  r.post('/login', authLimiter, ah(async (req, res) => {
    const identity = String(req.body.identity || '').trim();
    const pass = String(req.body.password || '');
    if (!identity || !pass || pass.length > 128 || identity.length > 254) {
      throw new HttpError(400, 'Enter your username, email or phone and your password.', 'VALIDATION');
    }
    let query;
    if (identity.includes('@')) query = { email: identity.toLowerCase() };
    else {
      const phone = identity.replace(/[\s\-().]/g, '');
      const username = identity.toLowerCase().replace(/^@/, '');
      query = /^\+?\d{7,15}$/.test(phone) ? { $or: [{ phone }, { username }] } : { username };
    }
    const user = await User.findOne(query).select('+passwordHash');
    const ok = await bcrypt.compare(pass, user?.passwordHash || DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'Incorrect username or password.', 'BAD_CREDENTIALS');

    if (!user.contactVerified) {
      const contact = user.email || user.phone;
      try { await issueOtp(contact, 'signup'); } catch { /* cooldown */ }
      throw new HttpError(403, 'Please verify your email or phone first. We sent you a new code.', 'NOT_VERIFIED');
    }
    setSessionCookie(res, user);
    res.json({ ok: true, user: meDTO(ctxFrom(req), user) });
  }));

  r.post('/logout', (req, res) => {
    clearSessionCookie(res);
    res.json({ ok: true });
  });

  /** "Log out of all devices". The current device stays signed in. */
  r.post('/logout-all', requireAuth, ah(async (req, res) => {
    req.user.tokenVersion += 1;
    await req.user.save();
    setSessionCookie(res, req.user);
    res.json({ ok: true });
  }));
  return r;
})();

// ---- routes/media.js ----
const mediaRoutes = (() => {
  const r = Router();
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: config.maxUploadBytes, files: 1 } });
  const uploadLimiter = rateLimit({
    windowMs: 10 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false,
    message: { error: 'Too many uploads. Please wait a few minutes.', code: 'RATE_LIMITED' },
  });

  /** Detect the real file type from magic bytes (never trust the client's mime type). SVG is intentionally not allowed. */
  function sniff(buf) {
    if (buf.length < 12) return null;
    const ascii = (a, b) => buf.toString('ascii', a, b);
    if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { type: 'image/jpeg', kind: 'image' };
    if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { type: 'image/png', kind: 'image' };
    if (ascii(0, 4) === 'GIF8') return { type: 'image/gif', kind: 'image' };
    if (ascii(0, 4) === 'RIFF' && ascii(8, 12) === 'WEBP') return { type: 'image/webp', kind: 'image' };
    if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return { type: 'video/webm', kind: 'video' };
    if (ascii(4, 8) === 'ftyp') {
      const brand = ascii(8, 12);
      if (brand === 'avif') return { type: 'image/avif', kind: 'image' };
      if (['heic', 'heix', 'hevc', 'hevx', 'mif1', 'msf1'].includes(brand)) return null; // browsers can't show HEIC
      return { type: brand === 'qt  ' ? 'video/quicktime' : 'video/mp4', kind: 'video' };
    }
    return null;
  }

  r.post('/', requireAuth, uploadLimiter, upload.single('file'), ah(async (req, res) => {
    if (!req.file) throw new HttpError(400, 'Attach a file in the "file" field.', 'VALIDATION');
    const info = sniff(req.file.buffer);
    if (!info) throw new HttpError(415, 'Only JPEG, PNG, WebP, GIF, AVIF, MP4, MOV and WebM files are allowed.', 'UNSUPPORTED');

    const id = await new Promise((resolve, reject) => {
      const stream = getBucket().openUploadStream(`upload-${Date.now()}`, {
        contentType: info.type,
        metadata: { owner: req.user._id, kind: info.kind },
      });
      stream.once('error', reject);
      stream.once('finish', () => resolve(stream.id));
      stream.end(req.file.buffer);
    });
    res.status(201).json({ id: String(id), url: mediaUrl(ctxFrom(req), id), kind: info.kind, contentType: info.type, size: req.file.size });
  }));

  /** Public, cacheable, supports Range requests so videos can seek. */
  r.get('/:id', ah(async (req, res) => {
    if (!isId(req.params.id)) throw new HttpError(404, 'File not found.', 'NOT_FOUND');
    const _id = toObjectId(req.params.id);
    const file = await getBucket().find({ _id }).limit(1).next();
    if (!file) throw new HttpError(404, 'File not found.', 'NOT_FOUND');

    const size = file.length;
    const etag = `"${file._id}"`;
    res.set({
      'Content-Type': file.contentType || 'application/octet-stream',
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'public, max-age=31536000, immutable',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'none'; sandbox",
      ETag: etag,
    });
    if (req.headers['if-none-match'] === etag) return res.status(304).end();

    let start = 0;
    let end = size - 1;
    if (req.headers.range) {
      const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range);
      if (!m || (m[1] === '' && m[2] === '')) { res.set('Content-Range', `bytes */${size}`); return res.status(416).end(); }
      if (m[1] === '') start = Math.max(0, size - Number(m[2]));
      else { start = Number(m[1]); if (m[2] !== '') end = Math.min(Number(m[2]), size - 1); }
      if (start > end || start >= size) { res.set('Content-Range', `bytes */${size}`); return res.status(416).end(); }
      res.status(206).set('Content-Range', `bytes ${start}-${end}/${size}`);
    }
    res.set('Content-Length', String(size === 0 ? 0 : end - start + 1));
    if (size === 0) return res.end();
    await pipeline(getBucket().openDownloadStream(_id, { start, end: end + 1 }), res).catch(() => {});
  }));
  return r;
})();

// ---- routes/users.js ----
const userRoutes = (() => {
  const r = Router();

  /* ---- Public: generated initials avatar for people without a photo ---- */
  const esc = (s) => s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  r.get('/:username/avatar.svg', ah(async (req, res) => {
    const username = String(req.params.username).toLowerCase();
    const u = await User.findOne({ username }).select('name username');
    const initials = (u?.name || '?').split(/\s+/).filter(Boolean).slice(0, 2).map((w) => [...w][0].toUpperCase()).join('') || '?';
    let h = 0;
    for (const ch of username) h = (h * 31 + ch.charCodeAt(0)) % 360;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="hsl(${h},55%,48%)"/><text x="50" y="50" dy=".35em" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="40" font-weight="600" fill="#fff">${esc(initials)}</text></svg>`;
    res.set({ 'Content-Type': 'image/svg+xml', 'Cache-Control': 'public, max-age=3600', 'Content-Security-Policy': "default-src 'none'; style-src 'unsafe-inline'; sandbox" }).send(svg);
  }));

  r.use(requireAuth);

  async function findUser(raw) {
    const username = String(raw || '').toLowerCase().replace(/^@/, '');
    const u = await User.findOne({ username });
    if (!u) throw new HttpError(404, 'User not found.', 'NOT_FOUND');
    return u;
  }

  async function profileDTO(ctx, u, me) {
    const [followers, following, posts, isFollowing, followsYou] = await Promise.all([
      Follow.countDocuments({ following: u._id }),
      Follow.countDocuments({ follower: u._id }),
      Post.countDocuments({ author: u._id }),
      Follow.exists({ follower: me._id, following: u._id }),
      Follow.exists({ follower: u._id, following: me._id }),
    ]);
    return { ...userDTO(ctx, u), followers, following, posts, isFollowing: !!isFollowing, followsYou: !!followsYou, isMe: String(me._id) === String(u._id) };
  }

  /* ---- Suggestions ---- */
  r.get('/suggestions', ah(async (req, res) => {
    const followed = await Follow.find({ follower: req.user._id }).distinct('following');
    const users = await User.find({ _id: { $nin: [...followed, req.user._id] }, contactVerified: true }).sort({ _id: -1 }).limit(pageLimit(req.query.limit, 8, 20));
    const ctx = ctxFrom(req);
    res.json({ users: users.map((u) => userDTO(ctx, u)) });
  }));

  /* ---- Me ---- */
  r.get('/me', (req, res) => res.json({ user: meDTO(ctxFrom(req), req.user) }));

  r.get('/me/close-friends', ah(async (req, res) => {
    const users = await User.find({ _id: { $in: req.user.closeFriendIds || [] } });
    const ctx = ctxFrom(req);
    res.json({ users: users.map((u) => userDTO(ctx, u)) });
  }));

  r.put('/me/close-friends', ah(async (req, res) => {
    const names = Array.isArray(req.body.usernames) ? req.body.usernames.slice(0, 500).map((n) => String(n).toLowerCase().replace(/^@/, '')) : [];
    const users = await User.find({ username: { $in: names }, _id: { $ne: req.user._id } }).select('_id');
    req.user.closeFriendIds = users.map((u) => u._id);
    await req.user.save();
    res.json({ ok: true, count: users.length });
  }));

  r.get('/me/export', ah(async (req, res) => {
    const ctx = ctxFrom(req);
    const [posts, comments, following] = await Promise.all([
      Post.find({ author: req.user._id }).sort({ _id: -1 }).limit(1000).select('caption location type createdAt').lean(),
      Comment.find({ author: req.user._id }).sort({ _id: -1 }).limit(1000).select('text post createdAt').lean(),
      Follow.find({ follower: req.user._id }).distinct('following'),
    ]);
    const followingUsers = await User.find({ _id: { $in: following } }).select('username');
    res.set('Content-Disposition', 'attachment; filename="luma-data.json"');
    res.json({ profile: meDTO(ctx, req.user), posts, comments, following: followingUsers.map((u) => u.username) });
  }));

  r.patch('/me', ah(async (req, res) => {
    const u = req.user;
    const body = req.body || {};
    let oldAvatar = null;
    if (body.name !== undefined) u.name = text(body.name, { name: 'Name', min: 1, max: 60 });
    if (body.bio !== undefined) u.bio = text(body.bio, { name: 'Bio', max: 160 });
    if (body.username !== undefined) {
      const next = normalizeUsername(body.username);
      if (next !== u.username) {
        if (await User.exists({ username: next })) throw new HttpError(409, 'That username is taken.', 'TAKEN');
        u.username = next;
      }
    }
    if (body.avatarMediaId !== undefined) {
      oldAvatar = u.avatarMediaId;
      if (body.avatarMediaId === null) u.avatarMediaId = null;
      else {
        const id = needId(body.avatarMediaId, 'avatarMediaId');
        const [file] = await findOwnedMedia([id], u._id);
        if (!file || file.metadata?.kind !== 'image') throw new HttpError(400, 'Choose an image you uploaded.', 'VALIDATION');
        u.avatarMediaId = file._id;
      }
    }
    await u.save();
    if (oldAvatar && String(oldAvatar) !== String(u.avatarMediaId)) await deleteMedia([oldAvatar]);
    res.json({ user: meDTO(ctxFrom(req), u) });
  }));

  r.patch('/me/settings', ah(async (req, res) => {
    const clean = {};
    for (const [k, v] of Object.entries(req.body || {}).slice(0, 60)) {
      if (!/^[a-zA-Z0-9_]{1,40}$/.test(k)) continue;
      if (typeof v === 'boolean' || (typeof v === 'number' && Number.isFinite(v)) || (typeof v === 'string' && v.length <= 100)) clean[k] = v;
    }
    req.user.settings = { ...(req.user.settings || {}), ...clean };
    req.user.markModified('settings');
    await req.user.save();
    res.json({ settings: req.user.settings });
  }));

  r.post('/me/password', ah(async (req, res) => {
    const next = checkPassword(req.body.next, 'New password');
    const user = await User.findById(req.user._id).select('+passwordHash');
    if (!(await bcrypt.compare(String(req.body.current || ''), user.passwordHash))) throw new HttpError(400, 'Current password is incorrect.', 'BAD_CREDENTIALS');
    user.passwordHash = await bcrypt.hash(next, 12);
    user.tokenVersion += 1;
    await user.save();
    setSessionCookie(res, user); // keep this device signed in, kick the others
    res.json({ ok: true });
  }));

  r.delete('/me', ah(async (req, res) => {
    const user = await User.findById(req.user._id).select('+passwordHash');
    if (!(await bcrypt.compare(String(req.body?.password || ''), user.passwordHash))) throw new HttpError(400, 'Password is incorrect.', 'BAD_CREDENTIALS');
    await deleteUser(user._id);
    clearSessionCookie(res);
    res.json({ ok: true });
  }));

  /* ---- Other people ---- */
  r.get('/:username', ah(async (req, res) => {
    const u = await findUser(req.params.username);
    res.json({ user: await profileDTO(ctxFrom(req), u, req.user) });
  }));

  r.get('/:username/posts', ah(async (req, res) => {
    const u = await findUser(req.params.username);
    const limit = pageLimit(req.query.limit, 12, 30);
    const q = { author: u._id };
    if (req.query.type === 'video') q.type = 'video';
    if (req.query.cursor) q._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Post.find(q).sort({ _id: -1 }).limit(limit + 1);
    const page = rows.slice(0, limit);
    res.json({ posts: await hydratePosts(ctxFrom(req), page, req.user), nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null });
  }));

  async function followList(req, res, direction) {
    const u = await findUser(req.params.username);
    const limit = pageLimit(req.query.limit, 30, 50);
    const mine = direction === 'followers' ? { following: u._id } : { follower: u._id };
    if (req.query.cursor) mine._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Follow.find(mine).sort({ _id: -1 }).limit(limit + 1).lean();
    const page = rows.slice(0, limit);
    const ids = page.map((f) => (direction === 'followers' ? f.follower : f.following));
    const [users, iFollow] = await Promise.all([
      User.find({ _id: { $in: ids } }),
      Follow.find({ follower: req.user._id, following: { $in: ids } }).distinct('following'),
    ]);
    const byId = new Map(users.map((x) => [String(x._id), x]));
    const followingSet = new Set(iFollow.map(String));
    const ctx = ctxFrom(req);
    res.json({
      users: ids.map((id) => byId.get(String(id))).filter(Boolean).map((x) => ({ ...userDTO(ctx, x), isFollowing: followingSet.has(String(x._id)) })),
      nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null,
    });
  }
  r.get('/:username/followers', ah((req, res) => followList(req, res, 'followers')));
  r.get('/:username/following', ah((req, res) => followList(req, res, 'following')));

  r.post('/:username/follow', ah(async (req, res) => {
    const target = await findUser(req.params.username);
    if (String(target._id) === String(req.user._id)) throw new HttpError(400, "You can't follow yourself.", 'VALIDATION');
    try {
      await Follow.create({ follower: req.user._id, following: target._id });
      await notify({ recipient: target._id, actor: req.user._id, type: 'follow' });
    } catch (e) { if (e.code !== 11000) throw e; } // already following
    res.json({ following: true, followers: await Follow.countDocuments({ following: target._id }) });
  }));

  r.delete('/:username/follow', ah(async (req, res) => {
    const target = await findUser(req.params.username);
    const result = await Follow.deleteOne({ follower: req.user._id, following: target._id });
    if (result.deletedCount) await unnotify({ recipient: target._id, actor: req.user._id, type: 'follow' });
    res.json({ following: false, followers: await Follow.countDocuments({ following: target._id }) });
  }));
  return r;
})();

// ---- routes/posts.js ----
const postRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  async function mustPost(id) {
    const post = await Post.findById(needId(id, 'post id'));
    if (!post) throw new HttpError(404, 'Post not found.', 'NOT_FOUND');
    return post;
  }

  const extractTags = (caption) =>
    [...new Set([...caption.matchAll(/#([\p{L}\p{N}_]{1,50})/gu)].map((m) => m[1].toLowerCase()))].slice(0, 30);

  /* ---- Feed: you + people you follow. If you follow nobody yet, show recent posts from everyone. ---- */
  r.get('/feed', ah(async (req, res) => {
    const limit = pageLimit(req.query.limit, 10, 30);
    const following = await Follow.find({ follower: req.user._id }).distinct('following');
    const discover = following.length === 0;
    const q = discover ? {} : { author: { $in: [req.user._id, ...following] } };
    if (req.query.cursor) q._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Post.find(q).sort({ _id: -1 }).limit(limit + 1);
    const page = rows.slice(0, limit);
    res.json({
      posts: await hydratePosts(ctxFrom(req), page, req.user),
      nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null,
      discover,
    });
  }));

  r.get('/saved', ah(async (req, res) => {
    const limit = pageLimit(req.query.limit, 12, 30);
    const q = { user: req.user._id };
    if (req.query.cursor) q._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Save.find(q).sort({ _id: -1 }).limit(limit + 1).lean();
    const page = rows.slice(0, limit);
    const posts = await Post.find({ _id: { $in: page.map((s) => s.post) } });
    const order = new Map(page.map((s, i) => [String(s.post), i]));
    posts.sort((a, b) => order.get(String(a._id)) - order.get(String(b._id)));
    res.json({
      posts: await hydratePosts(ctxFrom(req), posts, req.user),
      nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null,
    });
  }));

  /* ---- Create: upload files with POST /api/media first, then send their ids here ---- */
  r.post('/', ah(async (req, res) => {
    const ids = Array.isArray(req.body.mediaIds) ? [...new Set(req.body.mediaIds.map(String))] : [];
    if (ids.length < 1 || ids.length > 10) throw new HttpError(400, 'Add between 1 and 10 photos or one video.', 'VALIDATION');
    ids.forEach((id) => needId(id, 'mediaId'));
    const caption = text(req.body.caption, { name: 'Caption', max: 2200 });
    const location = text(req.body.location, { name: 'Location', max: 100 });
    const audio = text(req.body.audio, { name: 'Audio', max: 100 });

    const files = await findOwnedMedia(ids, req.user._id);
    if (files.some((f) => !f)) throw new HttpError(400, 'One of the files was not found. Upload it again.', 'VALIDATION');
    const kinds = files.map((f) => f.metadata?.kind);
    const hasVideo = kinds.includes('video');
    if (hasVideo && ids.length > 1) throw new HttpError(400, 'A video post can contain only one video.', 'VALIDATION');

    let posterId = null;
    if (hasVideo && req.body.posterId) {
      const [poster] = await findOwnedMedia([needId(String(req.body.posterId), 'posterId')], req.user._id);
      if (!poster || poster.metadata?.kind !== 'image') throw new HttpError(400, 'Poster must be an image you uploaded.', 'VALIDATION');
      posterId = poster._id;
    }

    const post = await Post.create({
      author: req.user._id,
      type: hasVideo ? 'video' : ids.length > 1 ? 'carousel' : 'image',
      media: files.map((f) => ({ mediaId: f._id, kind: f.metadata.kind })),
      posterId, audio, caption, location, tags: extractTags(caption),
    });
    const [dto] = await hydratePosts(ctxFrom(req), [post], req.user);
    res.status(201).json({ post: dto });
  }));

  r.get('/:id', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    const [dto] = await hydratePosts(ctxFrom(req), [post], req.user);
    if (!dto) throw new HttpError(404, 'Post not found.', 'NOT_FOUND');
    res.json({ post: dto });
  }));

  r.patch('/:id', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    if (String(post.author) !== String(req.user._id)) throw new HttpError(403, 'You can only edit your own posts.', 'FORBIDDEN');
    if (req.body.caption !== undefined) { post.caption = text(req.body.caption, { name: 'Caption', max: 2200 }); post.tags = extractTags(post.caption); }
    if (req.body.location !== undefined) post.location = text(req.body.location, { name: 'Location', max: 100 });
    await post.save();
    const [dto] = await hydratePosts(ctxFrom(req), [post], req.user);
    res.json({ post: dto });
  }));

  r.delete('/:id', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    if (String(post.author) !== String(req.user._id)) throw new HttpError(403, 'You can only delete your own posts.', 'FORBIDDEN');
    await deletePost(post);
    res.json({ ok: true });
  }));

  /* ---- Like ---- */
  async function setLike(req, res, on) {
    const post = await mustPost(req.params.id);
    if (on) {
      try {
        await Like.create({ user: req.user._id, post: post._id });
        await Post.updateOne({ _id: post._id }, { $inc: { likesCount: 1 } });
        await notify({ recipient: post.author, actor: req.user._id, type: 'like', post: post._id });
      } catch (e) { if (e.code !== 11000) throw e; } // already liked
    } else {
      const result = await Like.deleteOne({ user: req.user._id, post: post._id });
      if (result.deletedCount) {
        await Post.updateOne({ _id: post._id, likesCount: { $gt: 0 } }, { $inc: { likesCount: -1 } });
        await unnotify({ recipient: post.author, actor: req.user._id, type: 'like', post: post._id });
      }
    }
    const fresh = await Post.findById(post._id).select('likesCount');
    res.json({ liked: on, likes: fresh?.likesCount ?? 0 });
  }
  r.post('/:id/like', ah((req, res) => setLike(req, res, true)));
  r.delete('/:id/like', ah((req, res) => setLike(req, res, false)));

  /* ---- Save (bookmark) ---- */
  r.post('/:id/save', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    try { await Save.create({ user: req.user._id, post: post._id }); } catch (e) { if (e.code !== 11000) throw e; }
    res.json({ saved: true });
  }));
  r.delete('/:id/save', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    await Save.deleteOne({ user: req.user._id, post: post._id });
    res.json({ saved: false });
  }));

  /* ---- Comments (newest first) ---- */
  r.get('/:id/comments', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    const limit = pageLimit(req.query.limit, 20, 50);
    const q = { post: post._id };
    if (req.query.cursor) q._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Comment.find(q).sort({ _id: -1 }).limit(limit + 1).lean();
    const page = rows.slice(0, limit);
    const users = new Map((await User.find({ _id: { $in: page.map((c) => c.author) } })).map((u) => [String(u._id), u]));
    const ctx = ctxFrom(req);
    res.json({
      comments: page.filter((c) => users.has(String(c.author))).map((c) => commentDTO(ctx, c, users.get(String(c.author)))),
      nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null,
    });
  }));

  r.post('/:id/comments', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    const body = text(req.body.text, { name: 'Comment', min: 1, max: 500 });
    const comment = await Comment.create({ post: post._id, author: req.user._id, text: body });
    const updated = await Post.findByIdAndUpdate(post._id, { $inc: { commentsCount: 1 } }, { new: true }).select('commentsCount');
    await notify({ recipient: post.author, actor: req.user._id, type: 'comment', post: post._id, text: body });
    res.status(201).json({ comment: commentDTO(ctxFrom(req), comment, req.user), commentsCount: updated?.commentsCount ?? 0 });
  }));

  r.delete('/:id/comments/:commentId', ah(async (req, res) => {
    const post = await mustPost(req.params.id);
    const comment = await Comment.findOne({ _id: needId(req.params.commentId, 'comment id'), post: post._id });
    if (!comment) throw new HttpError(404, 'Comment not found.', 'NOT_FOUND');
    const mine = String(comment.author) === String(req.user._id);
    const myPost = String(post.author) === String(req.user._id);
    if (!mine && !myPost) throw new HttpError(403, 'You cannot delete this comment.', 'FORBIDDEN');
    await comment.deleteOne();
    await Post.updateOne({ _id: post._id, commentsCount: { $gt: 0 } }, { $inc: { commentsCount: -1 } });
    res.json({ ok: true });
  }));
  return r;
})();

// ---- routes/stories.js ----
const storyRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  const DAY_MS = 24 * 60 * 60 * 1000;

  function storyDTO(ctx, s, author, meId) {
    return {
      id: String(s._id),
      user: userDTO(ctx, author),
      ...(s.kind === 'video' ? { video: mediaUrl(ctx, s.mediaId), image: '' } : { image: mediaUrl(ctx, s.mediaId) }),
      kind: s.kind,
      time: shortTime(s.createdAt),
      createdAt: s.createdAt,
      expiresAt: s.expiresAt,
      closeFriends: !!s.closeFriends,
      seen: (s.viewers || []).some((v) => String(v) === String(meId)),
    };
  }

  /** Active stories from you + people you follow. Your own first, then unseen, then seen. */
  r.get('/', ah(async (req, res) => {
    const me = req.user;
    const following = await Follow.find({ follower: me._id }).distinct('following');
    const authorIds = [me._id, ...following];
    const [stories, authors] = await Promise.all([
      Story.find({ author: { $in: authorIds }, expiresAt: { $gt: new Date() } }).sort({ createdAt: 1 }).limit(300),
      User.find({ _id: { $in: authorIds } }),
    ]);
    const byId = new Map(authors.map((a) => [String(a._id), a]));
    const myId = String(me._id);
    const ctx = ctxFrom(req);

    const groups = new Map();
    for (const s of stories) {
      const author = byId.get(String(s.author));
      if (!author) continue;
      const isMine = String(s.author) === myId;
      if (s.closeFriends && !isMine && !(author.closeFriendIds || []).some((id) => String(id) === myId)) continue;
      const dto = storyDTO(ctx, s, author, me._id);
      if (!groups.has(dto.user.id)) groups.set(dto.user.id, []);
      groups.get(dto.user.id).push(dto);
    }
    const rank = ([id, items]) => (id === myId ? 0 : items.some((i) => !i.seen) ? 1 : 2);
    const ordered = [...groups.entries()].sort((a, b) => rank(a) - rank(b));
    res.json({ stories: ordered.flatMap(([, items]) => items) });
  }));

  r.post('/', ah(async (req, res) => {
    const id = needId(String(req.body.mediaId || ''), 'mediaId');
    const [file] = await findOwnedMedia([id], req.user._id);
    if (!file) throw new HttpError(400, 'File not found. Upload it again.', 'VALIDATION');
    const story = await Story.create({
      author: req.user._id, mediaId: file._id, kind: file.metadata?.kind || 'image',
      closeFriends: req.body.closeFriends === true, expiresAt: new Date(Date.now() + DAY_MS),
    });
    res.status(201).json({ story: storyDTO(ctxFrom(req), story, req.user, req.user._id) });
  }));

  r.post('/:id/view', ah(async (req, res) => {
    const story = await Story.findOneAndUpdate(
      { _id: needId(req.params.id, 'story id'), expiresAt: { $gt: new Date() } },
      { $addToSet: { viewers: req.user._id } },
    );
    if (!story) throw new HttpError(404, 'Story not found.', 'NOT_FOUND');
    res.json({ ok: true });
  }));

  /** Who watched my story (owner only). */
  r.get('/:id/viewers', ah(async (req, res) => {
    const story = await Story.findOne({ _id: needId(req.params.id, 'story id'), author: req.user._id });
    if (!story) throw new HttpError(404, 'Story not found.', 'NOT_FOUND');
    const users = await User.find({ _id: { $in: story.viewers.slice(-200) } });
    const ctx = ctxFrom(req);
    res.json({ count: story.viewers.length, users: users.map((u) => userDTO(ctx, u)) });
  }));

  r.delete('/:id', ah(async (req, res) => {
    const story = await Story.findOneAndDelete({ _id: needId(req.params.id, 'story id'), author: req.user._id });
    if (!story) throw new HttpError(404, 'Story not found.', 'NOT_FOUND');
    await deleteMedia([story.mediaId]);
    res.json({ ok: true });
  }));
  return r;
})();

// ---- routes/reels.js ----
const reelRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  /** Reels = video posts from everyone, newest first. Like / comment / save them via /api/posts/:id/... */
  r.get('/', ah(async (req, res) => {
    const limit = pageLimit(req.query.limit, 8, 20);
    const q = { type: 'video' };
    if (req.query.cursor) q._id = { $lt: needId(req.query.cursor, 'cursor') };
    const rows = await Post.find(q).sort({ _id: -1 }).limit(limit + 1);
    const page = rows.slice(0, limit);
    const posts = await hydratePosts(ctxFrom(req), page, req.user);
    res.json({
      reels: posts.map((p) => ({
        id: p.id, user: p.user, video: p.video, poster: p.poster || p.image, caption: p.caption,
        audio: p.audio || `Original audio · ${p.user.username}`,
        likes: p.likes, comments: p.commentsCount, commentsPreview: p.comments,
        liked: p.liked, saved: p.saved, time: p.time, createdAt: p.createdAt,
      })),
      nextCursor: rows.length > limit ? String(page[page.length - 1]._id) : null,
    });
  }));
  return r;
})();

// ---- routes/conversations.js ----
const conversationRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  const pairKeyOf = (a, b) => [String(a), String(b)].sort().join(':');
  const otherOf = (conv, meId) => conv.participants.find((p) => String(p) !== String(meId));

  async function mustConversation(id, me) {
    const conv = await Conversation.findOne({ _id: needId(id, 'conversation id'), participants: me._id });
    if (!conv) throw new HttpError(404, 'Conversation not found.', 'NOT_FOUND');
    return conv;
  }

  function convDTO(ctx, c, other, meId) {
    return {
      id: String(c._id),
      user: userDTO(ctx, other),
      lastMessage: c.lastText || '',
      lastSender: c.lastSender ? (String(c.lastSender) === String(meId) ? 'me' : 'them') : null,
      time: c.lastText ? shortTime(c.lastMessageAt) : '',
      lastMessageAt: c.lastMessageAt,
      unread: Number(c.unread?.[String(meId)]) || 0,
    };
  }

  function messageDTO(m, meId) {
    return {
      id: String(m._id),
      from: String(m.sender) === String(meId) ? 'me' : 'them',
      text: m.deleted ? '' : m.text,
      deleted: !!m.deleted,
      reaction: m.reaction || undefined,
      time: shortTime(m.createdAt),
      createdAt: m.createdAt,
    };
  }

  /* ---- Inbox ---- */
  r.get('/', ah(async (req, res) => {
    const convs = await Conversation.find({ participants: req.user._id, lastText: { $ne: '' } }).sort({ lastMessageAt: -1 }).limit(60).lean();
    const otherIds = convs.map((c) => otherOf(c, req.user._id));
    const users = new Map((await User.find({ _id: { $in: otherIds } })).map((u) => [String(u._id), u]));
    const ctx = ctxFrom(req);
    const items = convs
      .map((c) => ({ c, other: users.get(String(otherOf(c, req.user._id))) }))
      .filter((x) => x.other)
      .map((x) => convDTO(ctx, x.c, x.other, req.user._id));
    res.json({ conversations: items, unreadTotal: items.reduce((n, c) => n + c.unread, 0) });
  }));

  /** Start (or reopen) a 1-to-1 chat with { username }. */
  r.post('/', ah(async (req, res) => {
    const username = String(req.body.username || '').toLowerCase().replace(/^@/, '');
    const target = await User.findOne({ username });
    if (!target) throw new HttpError(404, 'User not found.', 'NOT_FOUND');
    if (String(target._id) === String(req.user._id)) throw new HttpError(400, "You can't message yourself.", 'VALIDATION');
    const conv = await Conversation.findOneAndUpdate(
      { pairKey: pairKeyOf(req.user._id, target._id) },
      { $setOnInsert: { participants: [req.user._id, target._id] } },
      { upsert: true, new: true },
    );
    res.status(201).json({ conversation: convDTO(ctxFrom(req), conv, target, req.user._id) });
  }));

  /* ---- Messages. Poll with ?after=<lastMessageId> for new ones. ---- */
  r.get('/:id/messages', ah(async (req, res) => {
    const conv = await mustConversation(req.params.id, req.user);
    const limit = pageLimit(req.query.limit, 40, 100);
    const q = { conversation: conv._id };
    const after = req.query.after ? needId(req.query.after, 'after') : null;
    if (after) q._id = { $gt: after };
    else if (req.query.before) q._id = { $lt: needId(req.query.before, 'before') };

    let rows = await Message.find(q).sort({ _id: after ? 1 : -1 }).limit(limit + 1).lean();
    const hasMore = rows.length > limit;
    rows = rows.slice(0, limit);
    if (!after) rows.reverse(); // always return oldest -> newest

    await Conversation.updateOne({ _id: conv._id }, { $set: { [`unread.${req.user._id}`]: 0 } });
    res.json({ messages: rows.map((m) => messageDTO(m, req.user._id)), hasMore });
  }));

  r.post('/:id/messages', ah(async (req, res) => {
    const conv = await mustConversation(req.params.id, req.user);
    const body = text(req.body.text, { name: 'Message', min: 1, max: 2000 });
    const msg = await Message.create({ conversation: conv._id, sender: req.user._id, text: body });
    await Conversation.updateOne({ _id: conv._id }, {
      $set: { lastText: body.slice(0, 200), lastSender: req.user._id, lastMessageAt: msg.createdAt },
      $inc: { [`unread.${otherOf(conv, req.user._id)}`]: 1 },
    });
    res.status(201).json({ message: messageDTO(msg, req.user._id) });
  }));

  r.put('/:id/messages/:messageId/reaction', ah(async (req, res) => {
    const conv = await mustConversation(req.params.id, req.user);
    const emoji = text(req.body.emoji, { name: 'Reaction', max: 8 });
    const msg = await Message.findOneAndUpdate(
      { _id: needId(req.params.messageId, 'message id'), conversation: conv._id },
      { reaction: emoji }, { new: true },
    );
    if (!msg) throw new HttpError(404, 'Message not found.', 'NOT_FOUND');
    res.json({ message: messageDTO(msg, req.user._id) });
  }));

  r.delete('/:id/messages/:messageId', ah(async (req, res) => {
    const conv = await mustConversation(req.params.id, req.user);
    const msg = await Message.findOneAndUpdate(
      { _id: needId(req.params.messageId, 'message id'), conversation: conv._id, sender: req.user._id },
      { deleted: true, text: '', reaction: '' }, { new: true },
    );
    if (!msg) throw new HttpError(404, 'Message not found.', 'NOT_FOUND');
    res.json({ message: messageDTO(msg, req.user._id) });
  }));
  return r;
})();

// ---- routes/notifications.js ----
const notificationRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  r.get('/', ah(async (req, res) => {
    const limit = pageLimit(req.query.limit, 30, 50);
    const q = { recipient: req.user._id };
    if (req.query.before) {
      const d = new Date(String(req.query.before));
      if (Number.isNaN(d.getTime())) throw new HttpError(400, 'Invalid before date.', 'VALIDATION');
      q.createdAt = { $lt: d };
    }
    const rows = await Notification.find(q).sort({ createdAt: -1 }).limit(limit + 1).lean();
    const page = rows.slice(0, limit);
    const [actors, posts, unreadCount] = await Promise.all([
      User.find({ _id: { $in: page.map((n) => n.actor) } }),
      Post.find({ _id: { $in: page.map((n) => n.post).filter(Boolean) } }).select('media posterId type'),
      Notification.countDocuments({ recipient: req.user._id, read: false }),
    ]);
    const actorMap = new Map(actors.map((u) => [String(u._id), u]));
    const postMap = new Map(posts.map((p) => [String(p._id), p]));
    const ctx = ctxFrom(req);
    res.json({
      notifications: page.filter((n) => actorMap.has(String(n.actor))).map((n) => ({
        id: String(n._id),
        type: n.type,
        user: userDTO(ctx, actorMap.get(String(n.actor))),
        post: n.post ? thumbDTO(ctx, postMap.get(String(n.post))) : null,
        text: n.text || '',
        read: n.read,
        time: shortTime(n.createdAt),
        createdAt: n.createdAt,
      })),
      unreadCount,
      nextCursor: rows.length > limit ? new Date(page[page.length - 1].createdAt).toISOString() : null,
    });
  }));

  r.get('/unread-count', ah(async (req, res) => {
    res.json({ unreadCount: await Notification.countDocuments({ recipient: req.user._id, read: false }) });
  }));

  r.post('/read', ah(async (req, res) => {
    await Notification.updateMany({ recipient: req.user._id, read: false }, { read: true });
    res.json({ ok: true });
  }));

  r.post('/:id/read', ah(async (req, res) => {
    await Notification.updateOne({ _id: needId(req.params.id, 'notification id'), recipient: req.user._id }, { read: true });
    res.json({ ok: true });
  }));
  return r;
})();

// ---- routes/misc.js ----
const miscRoutes = (() => {
  const r = Router();
  r.use(requireAuth);

  function gridItem(ctx, p) {
    const video = (p.media || []).find((m) => m.kind === 'video');
    return { ...thumbDTO(ctx, p), ...(video ? { video: mediaUrl(ctx, video.mediaId) } : {}), likes: p.likesCount, commentsCount: p.commentsCount };
  }

  /** Explore grid: most-liked posts from other people. ?page=1&limit=24 */
  r.get('/explore', ah(async (req, res) => {
    const limit = pageLimit(req.query.limit, 24, 48);
    const page = Math.min(Math.max(parseInt(req.query.page, 10) || 1, 1), 50);
    const rows = await Post.find({ author: { $ne: req.user._id } })
      .sort({ likesCount: -1, _id: -1 }).skip((page - 1) * limit).limit(limit + 1)
      .select('media posterId type likesCount commentsCount');
    const ctx = ctxFrom(req);
    res.json({ items: rows.slice(0, limit).map((p) => gridItem(ctx, p)), page, hasMore: rows.length > limit });
  }));

  /** ?q=maya -> people. ?q=%23travel -> posts with that hashtag. */
  r.get('/search', ah(async (req, res) => {
    const q = String(req.query.q || '').trim().slice(0, 50);
    if (!q) return res.json({ users: [], posts: [] });
    const ctx = ctxFrom(req);
    if (q.startsWith('#')) {
      const tag = q.slice(1).toLowerCase();
      if (!tag) return res.json({ users: [], posts: [] });
      const posts = await Post.find({ tags: tag }).sort({ _id: -1 }).limit(30).select('media posterId type likesCount commentsCount');
      return res.json({ users: [], posts: posts.map((p) => gridItem(ctx, p)) });
    }
    const rx = escapeRegex(q);
    const users = await User.find({
      contactVerified: true,
      $or: [{ username: new RegExp(`^${rx.toLowerCase()}`) }, { name: new RegExp(`^${rx}`, 'i') }],
    }).limit(20);
    res.json({ users: users.map((u) => userDTO(ctx, u)), posts: [] });
  }));

  /** My recent likes and comments (Settings -> Your activity). */
  r.get('/activity', ah(async (req, res) => {
    const [likes, comments] = await Promise.all([
      Like.find({ user: req.user._id }).sort({ _id: -1 }).limit(30).lean(),
      Comment.find({ author: req.user._id }).sort({ _id: -1 }).limit(30).lean(),
    ]);
    const postIds = [...new Set([...likes.map((l) => String(l.post)), ...comments.map((c) => String(c.post))])];
    const posts = new Map((await Post.find({ _id: { $in: postIds } }).select('media posterId type')).map((p) => [String(p._id), p]));
    const ctx = ctxFrom(req);
    const items = [
      ...likes.map((l) => ({ id: String(l._id), type: 'like', post: l.post, text: '', createdAt: l.createdAt })),
      ...comments.map((c) => ({ id: String(c._id), type: 'comment', post: c.post, text: c.text, createdAt: c.createdAt })),
    ]
      .filter((i) => posts.has(String(i.post)))
      .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
      .slice(0, 40)
      .map((i) => ({ ...i, post: thumbDTO(ctx, posts.get(String(i.post))), time: shortTime(i.createdAt) }));
    res.json({ items });
  }));

  /** Report a post / user / comment / story / message. */
  r.post('/reports', ah(async (req, res) => {
    const targetType = String(req.body.targetType || '');
    if (!['post', 'user', 'comment', 'story', 'message'].includes(targetType)) throw new HttpError(400, 'Unknown report type.', 'VALIDATION');
    const target = text(String(req.body.target || ''), { name: 'Target', min: 1, max: 60 });
    if (targetType !== 'user') needId(target, 'target');
    const reason = text(req.body.reason, { name: 'Reason', min: 1, max: 100 });
    const details = text(req.body.details, { name: 'Details', max: 1000 });
    await Report.create({ reporter: req.user._id, targetType, target, reason, details });
    res.status(201).json({ ok: true });
  }));
  return r;
})();


// ======================================================================
// APP
// ======================================================================

const app = express();
app.set('trust proxy', 1); // Railway sits behind a proxy: needed for real client IPs and https detection
app.disable('x-powered-by');

app.use(helmet({ crossOriginResourcePolicy: { policy: 'cross-origin' } })); // media must load on the frontend's domain
app.use(cors({
  origin: (origin, cb) => cb(null, !origin || config.allowedOrigins.includes(origin.replace(/\/+$/, ''))),
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  maxAge: 600,
}));
app.use(express.json({ limit: '100kb' }));
app.use(cookieParser());

app.get('/', (req, res) => res.json({ name: 'Luma API', status: 'ok' }));
app.get('/health', (req, res) => {
  const dbUp = mongoose.connection.readyState === 1;
  res.status(dbUp ? 200 : 503).json({ ok: dbUp, db: dbUp ? 'up' : 'down' });
});

app.use('/api', rateLimit({
  windowMs: 15 * 60 * 1000, limit: 1500, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many requests. Please slow down.', code: 'RATE_LIMITED' },
}));
app.use('/api', originGuard, loadUser);

app.use('/api/auth', authRoutes);
app.use('/api/media', mediaRoutes);
app.use('/api/users', userRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/stories', storyRoutes);
app.use('/api/reels', reelRoutes);
app.use('/api/conversations', conversationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api', miscRoutes); // /explore /search /activity /reports

app.use(notFound);
app.use(errorHandler);


// ======================================================================
// START
// ======================================================================

async function main() {
  await connectDb();

  if (config.requireVerification && !config.resendApiKey && !config.logOtp) {
    console.warn("WARNING: REQUIRE_VERIFICATION is on but no RESEND_API_KEY and LOG_OTP=false -> nobody can receive codes.");
  }
  if (config.isProd && !config.publicUrl) {
    console.warn("WARNING: PUBLIC_URL is not set. Media URLs will be built from the request host.");
  }

  const server = app.listen(config.port, "0.0.0.0", () => {
    console.log(`Luma API listening on :${config.port} (${config.isProd ? "production" : "development"})`);
  });

  const timer = setInterval(() => cleanupExpiredStories().catch((e) => console.error("cleanup failed", e.message)), 60 * 60 * 1000);
  timer.unref();

  async function shutdown(signal) {
    console.log(`${signal} received, shutting down...`);
    clearInterval(timer);
    server.close(async () => { await mongoose.connection.close(); process.exit(0); });
    setTimeout(() => process.exit(1), 10000).unref();
  }
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("unhandledRejection", (err) => console.error("Unhandled rejection:", err));
}
main().catch((err) => { console.error("Startup failed:", err.message); process.exit(1); });
